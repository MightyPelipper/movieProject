<!DOCTYPE html>
<head>
    <!-- Link the stylesheet-->

    <link rel="stylesheet" href="prototype.css">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:700" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Arimo" rel="stylesheet"> 
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

</head>

<title>
    Home
</title>

<body>

    <div class="header">
        <h1>Twin Cities Cinema</h1>
    </div>


    <div class="container">
    
    <ul>
        <li><a href="empLogin.php">Login as Employee</a></li>
        <li><a href="adminLogin.php">Login as Admin</a></li>
        

        
    </ul>
    </div>

</body>
