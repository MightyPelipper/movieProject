<?php

$dbservername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "loginsystem";

$conn = mysqli_connect($dbservername, $dbUsername, $dbPassword, $dbName);